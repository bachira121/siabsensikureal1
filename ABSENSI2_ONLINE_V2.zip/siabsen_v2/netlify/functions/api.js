const { createClient } = require('@supabase/supabase-js');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {auth:{persistSession:false,autoRefreshToken:false}});
const GMAIL_USER=process.env.GMAIL_USER, GMAIL_APP_PASSWORD=process.env.GMAIL_APP_PASSWORD;
const GURU_PIKET_EMAIL=process.env.GURU_PIKET_EMAIL||process.env.ADMIN_EMAIL||'siabsenkuofficial1@gmail.com';
const OTP_MINUTES=10;
const out=(status,body)=>({statusCode:status,headers:{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,OPTIONS'},body:JSON.stringify(body)});
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Jakarta'}).format(new Date());
const nowTime=()=>new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date());
const isWeekday=()=>!['Sat','Sun'].includes(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Jakarta',weekday:'short'}).format(new Date()));
const validClass=k=>/^(X\.[1-6]|XI\.[1-6]|XII\.[1-7])$/.test(String(k||'').toUpperCase());
const hash=async s=>bcrypt.hash(String(s),10);
const mapA=a=>({id:a.id,nama:a.nama,kelas:a.kelas,tanggal:a.tanggal,jam:a.jam,guru:a.guru,dipindaiOleh:a.dipindai_oleh});
const mapI=i=>({id:i.id,nama:i.nama,kelas:i.kelas,jenis:i.jenis,keterangan:i.keterangan,bukti:i.bukti,namaBukti:i.nama_bukti,tipeBukti:i.tipe_bukti,tanggal:i.tanggal,jam:i.jam,status:i.status,diprosesOleh:i.diproses_oleh,diprosesTanggal:i.diproses_tanggal,diprosesJam:i.diproses_jam});
async function rows(table){const {data,error}=await supabase.from(table).select('*');if(error)throw error;return data||[];}
function mailer(){if(!GMAIL_USER||!GMAIL_APP_PASSWORD)throw new Error('Email server belum dikonfigurasi di Netlify Environment Variables.');return nodemailer.createTransport({service:'gmail',auth:{user:GMAIL_USER,pass:GMAIL_APP_PASSWORD}});}
exports.handler=async event=>{
 if(event.httpMethod==='OPTIONS')return out(204,{});
 if(event.httpMethod!=='POST')return out(405,{ok:false,error:'Method tidak diizinkan.'});
 try{
  const b=JSON.parse(event.body||'{}'), a=b.action;
  if(a==='send-otp'){
   const {role,nama,gelar,jurusan,email,password}=b;if(!['guru','guruPiket'].includes(role))throw Error('Role tidak valid.');if(!nama||!gelar||!jurusan||!email||!password)throw Error('Semua data guru wajib diisi.');if(password.length<6)throw Error('Password minimal 6 karakter.');
   const code=String(Math.floor(100000+Math.random()*900000));
   const {error}=await supabase.from('otp_requests').upsert({email:email.toLowerCase(),role,code_hash:await hash(code),expires_at:new Date(Date.now()+OTP_MINUTES*60000).toISOString(),nama,gelar,jurusan,password_hash:await hash(password)},{onConflict:'email,role'});if(error)throw error;
   await mailer().sendMail({from:`SIABSEN <${GMAIL_USER}>`,to:email.toLowerCase(),subject:`Kode OTP SIABSEN - ${code}`,text:`Kode OTP SIABSEN Anda: ${code}. Berlaku ${OTP_MINUTES} menit.`});
   return out(200,{ok:true,message:'OTP terkirim.'});
  }
  if(a==='verify-otp'){
   const {role,nama,gelar,jurusan,email,password,otp}=b;const {data:req,error}=await supabase.from('otp_requests').select('*').eq('email',email.toLowerCase()).eq('role',role).maybeSingle();if(error)throw error;if(!req)throw Error('OTP tidak ditemukan. Minta OTP baru.');if(Date.parse(req.expires_at)<Date.now())throw Error('OTP sudah kedaluwarsa.');if(!(await bcrypt.compare(String(otp),req.code_hash)))throw Error('OTP salah.');
   const {data:old,error:e}=await supabase.from('staff_users').select('*').eq('email',email.toLowerCase()).eq('role',role).maybeSingle();if(e)throw e;if(old&&!(await bcrypt.compare(password,old.password_hash)))throw Error('Password salah.');
   const {data:user,error:e2}=await supabase.from('staff_users').upsert({email:email.toLowerCase(),role,nama,gelar,jurusan,password_hash:old?old.password_hash:req.password_hash,verified_at:new Date().toISOString()},{onConflict:'email,role'}).select('id,email,role,nama,gelar,jurusan').single();if(e2)throw e2;
   await supabase.from('otp_requests').delete().eq('email',email.toLowerCase()).eq('role',role);return out(200,{ok:true,user});
  }
  if(a==='bootstrap'){
   const {role,email}=b;const {data:u}=await supabase.from('staff_users').select('id').eq('email',String(email||'').toLowerCase()).eq('role',role).maybeSingle();if(!u)throw Error('Akun belum terverifikasi.');
   return out(200,{ok:true,absensi:(await rows('attendance')).map(mapA),izin:(await rows('permissions')).map(mapI)});
  }
  if(a==='student-data'){
   const {nama,kelas}=b;if(!nama||!validClass(kelas))throw Error('Data siswa tidak valid.');
   const {data:aa,error:ae}=await supabase.from('attendance').select('*').ilike('nama',nama).eq('kelas',String(kelas).toUpperCase());if(ae)throw ae;const {data:ii,error:ie}=await supabase.from('permissions').select('*').ilike('nama',nama).eq('kelas',String(kelas).toUpperCase());if(ie)throw ie;return out(200,{ok:true,absensi:(aa||[]).map(mapA),izin:(ii||[]).map(mapI)});
  }
  if(a==='submit-izin'){
   if(!isWeekday())throw Error('Pengajuan izin hanya dibuka Senin-Jumat.');
   const {nama,kelas,jenis,keterangan,bukti,namaBukti,tipeBukti}=b;if(!nama||!validClass(kelas)||!jenis||!keterangan||!bukti)throw Error('Data surat izin belum lengkap.');
   if(!['Izin sakit','Izin ada urusan'].includes(jenis))throw Error('Jenis izin tidak valid.');if(jenis==='Izin sakit'&&!String(tipeBukti).startsWith('image/'))throw Error('Bukti izin sakit harus berupa gambar.');if(jenis==='Izin ada urusan'&&!String(tipeBukti).startsWith('video/'))throw Error('Bukti izin urusan harus berupa video.');if(jenis==='Izin ada urusan'&&String(bukti).length>12*1024*1024)throw Error('Bukti video terlalu besar.');
   const d=today();const {data:x,error:xe}=await supabase.from('permissions').select('id').eq('nama',nama).eq('kelas',String(kelas).toUpperCase()).eq('tanggal',d).maybeSingle();if(xe)throw xe;if(x)throw Error('Kamu sudah mengirim 1 surat izin hari ini.');
   const {data:r,error}=await supabase.from('permissions').insert({nama,kelas:String(kelas).toUpperCase(),jenis,keterangan,bukti,nama_bukti:namaBukti,tipe_bukti:tipeBukti,tanggal:d,jam:nowTime(),status:'Menunggu'}).select('*').single();if(error)throw error;
   try{await mailer().sendMail({from:`SIABSEN <${GMAIL_USER}>`,to:GURU_PIKET_EMAIL,subject:`Surat Izin Baru - ${nama} (${kelas})`,text:`Siswa: ${nama}\nKelas: ${kelas}\nJenis: ${jenis}\nTanggal: ${d}\nJam: ${nowTime()}\nKeterangan: ${keterangan}\nStatus: Menunggu`});}catch(mailErr){console.error(mailErr);}
   return out(200,{ok:true,row:mapI(r),izin:(await rows('permissions')).map(mapI)});
  }
  if(a==='update-izin-status'){
   const {id,status,processedBy,processedRole}=b;if(!['Disetujui','Ditolak'].includes(status)||!['guru','guruPiket'].includes(processedRole))throw Error('Permintaan tidak valid.');
   const {data:r,error}=await supabase.from('permissions').update({status,diproses_oleh:processedBy,diproses_tanggal:today(),diproses_jam:nowTime()}).eq('id',id).select('*').single();if(error)throw error;return out(200,{ok:true,row:mapI(r),izin:(await rows('permissions')).map(mapI)});
  }
  if(a==='scan-absensi'){
   const {nama,kelas,guru,dipindaiOleh}=b;if(!nama||!validClass(kelas))throw Error('QR siswa tidak valid.');const d=today();const {data:x,error:xe}=await supabase.from('attendance').select('id').eq('nama',nama).eq('kelas',String(kelas).toUpperCase()).eq('tanggal',d).maybeSingle();if(xe)throw xe;if(x)throw Error(`${nama} sudah melakukan absensi hari ini.`);
   const {data:r,error}=await supabase.from('attendance').insert({nama,kelas:String(kelas).toUpperCase(),tanggal:d,jam:nowTime(),guru,dipindai_oleh:dipindaiOleh}).select('*').single();if(error)throw error;return out(200,{ok:true,row:mapA(r),absensi:(await rows('attendance')).map(mapA)});
  }
  if(a==='public-data'){return out(200,{ok:true,absensi:(await rows('attendance')).map(mapA),izin:[]});}
  throw Error('Action tidak dikenal.');
 }catch(e){console.error(e);return out(400,{ok:false,error:e.message||'Terjadi kesalahan server.'});}
};
