SIABSEN V2 - PAKET DEPLOY ONLINE

Lihat README_DEPLOY_V2.txt untuk setup Supabase, Gmail OTP, Environment Variables, dan deploy Netlify.

Jalankan schema.sql di Supabase SQL Editor sebelum deploy.
Jangan memasukkan SUPABASE_SERVICE_ROLE_KEY atau GMAIL_APP_PASSWORD ke index.html.
