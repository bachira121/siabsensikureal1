SIABSEN V2 - DEPLOY ONLINE
==========================

1. SUPABASE
- Buat project di Supabase.
- Buka SQL Editor.
- Jalankan isi schema.sql.
- Ambil Project URL dan Service Role Key dari Project Settings > API.
- Service Role Key hanya disimpan di Netlify Environment Variables.

2. GMAIL OTP
- Gunakan akun admin: siabsenkuofficial1@gmail.com.
- Aktifkan 2-Step Verification pada akun Google.
- Buat Google App Password.
- Jangan masukkan password Gmail biasa atau App Password ke index.html.

3. NETLIFY ENVIRONMENT VARIABLES
Isi:
SUPABASE_URL
SUPABASE_SERVICE_ROLE_KEY
GMAIL_USER=siabsenkuofficial1@gmail.com
GMAIL_APP_PASSWORD=App-Password-Google
ADMIN_EMAIL=siabsenkuofficial1@gmail.com
GURU_PIKET_EMAIL=siabsenkuofficial1@gmail.com

4. DEPLOY
- Upload folder/ZIP ini ke Netlify atau hubungkan repository.
- Build command kosong.
- Publish directory: .
- Functions directory: netlify/functions

5. FITUR ONLINE V2
- Guru dan Guru Piket memakai email + password + OTP.
- Data absensi tersimpan di database, bukan hanya localStorage.
- Data izin tersimpan di database.
- Izin otomatis dikirim melalui email ke GURU_PIKET_EMAIL.
- Siswa tidak membutuhkan email/password.
- Satu siswa hanya dapat mengirim 1 izin per hari.
- Pengajuan izin ditutup Sabtu-Minggu dan dicek di backend.
- Izin sakit wajib gambar.
- Izin urusan wajib video.
- Video dibatasi maksimal 8 MB pada frontend; backend juga menolak payload yang terlalu besar.

CATATAN PENTING
V2 ini sudah memakai backend/database untuk data utama, tetapi bukti masih dikirim sebagai data URL ke function. Netlify memiliki batas payload function, sehingga video mendekati 8 MB dapat terkena batas platform. Untuk produksi dengan bukti video besar, tahap berikutnya sebaiknya memakai Supabase Storage direct upload.
